main = ('Bold', 19)
sub = ('Bold', 10)
mid = ('Bold', 12)
search_font = ('Bold', 15)