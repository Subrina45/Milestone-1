main = ('Bold', 13)
sub = ('Bold', 10)
mid = ('Bold', 12)